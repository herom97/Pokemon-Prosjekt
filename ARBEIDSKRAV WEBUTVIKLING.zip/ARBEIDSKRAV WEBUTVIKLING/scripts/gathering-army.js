// Importerer armyModules og funksjoner fra resourceUtil
import armyModules from "./modules/armyModules.js";
import { loadResources, updateResources, saveResources, getResources } from "./utilities/resourceUtil.js";

// Funksjon for å lagre kjøpte enheter i localStorage
const saveToArmy = (item) => {
    let army = JSON.parse(localStorage.getItem('armyResources')) || []; 
    army.push(item); // Bruk det filtrerte objektet 'item'
    localStorage.setItem('armyResources', JSON.stringify(army)); // Lagrer tilbake til localStorage 
};


// Funksjon for å håndtere kjøpsklikk
const buyItem = (costGold, costMetal = 0, costWood = 0, item) => {    
    const resources = getResources();  

    if (resources.gold >= costGold && resources.metal >= costMetal && resources.wood >= costWood) {
        resources.gold -= costGold;
        resources.metal -= costMetal;
        resources.wood -= costWood;
        updateResources();
        saveResources();
        saveToArmy(item);  // Lagring av kjøpte enheter
    } else {
        alert("Not enough resources to buy this item.");
    }
};

// Funksjon for å vise items basert på kategori
const displayWarriors = () => {
    armyModules.showItems('warriors-grid', 'Warrior');
};

const displayCombatForces = () => {
    armyModules.showItems('combat-weapons-grid', 'Combat Force');
};

// Funksjon for å legge til kunne klikk på kjøpsknapp 
function buyButtonClick() {
    const buttons = document.querySelectorAll(".card button");

    buttons.forEach(button => {
        button.addEventListener("click", function () {
            const itemName = this.parentElement.querySelector("h3").innerText; // Henter navn fra h3 

            // Finner elementet basert på navn fra armyItems arrayen
            const item = armyModules.armyItems.find(i => i.name === itemName);

            if (item) {
                buyItem(item.priceGold, item.priceMetal || 0, item.priceWood || 0, item); 
            }
        });
    });
}

// Oppdaterer siden med de nye resources
window.onload = () => {
    loadResources(); // Laster ressurser fra localStorage
    updateResources(); // Oppdaterer visningen av ressurser i navbaren
    displayWarriors(); // Viser warriors
    displayCombatForces();
    buyButtonClick();

};