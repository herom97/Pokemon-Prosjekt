// Initialize resource values
let resources = {
  gold: 0,
  metal: 0,
  wood: 0
};

// Saves resource variables to local storage and converts object to JSON string
 export function saveResources() {
  localStorage.setItem("resources", JSON.stringify(resources));
  }

// gets resources from local storage
export function loadResources() {
  const storedResources = JSON.parse(localStorage.getItem("resources"));
  if (storedResources) {
    resources.gold = storedResources.gold || 0;
    resources.metal = storedResources.metal || 0;
    resources.wood = storedResources.wood || 0;
  }
}

// Updates resource amounts displayed on the page
export function updateResources() {
  document.getElementById("gold-amount").innerText = `Gold: ${resources.gold}`;
  document.getElementById("metal-amount").innerText = `Metal: ${resources.metal}`;
  document.getElementById("wood-amount").innerText = `Wood: ${resources.wood}`;
  saveResources();
}

export function getResources() {
  return resources;
}