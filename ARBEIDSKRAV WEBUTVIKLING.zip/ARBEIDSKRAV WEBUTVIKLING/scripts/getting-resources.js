import { loadResources, updateResources, getResources } from "./utilities/resourceUtil.js";

window.onload = () => {
  const mineBtn = document.getElementById("mineBtn");
  const woodBtn = document.getElementById("woodsBtn");

  // Loads resources from local storage and updates the display
  loadResources();
  updateResources();

  // Makes the mine picture clickable
  mineBtn.addEventListener("click", () => {
    const resources = getResources();
    const random = Math.random();
    if (random < 0.50) {
      // You get gold
      resources.gold += Math.floor(Math.random() * 100) + 1;
    } else {
      // Otherwise, you get metal
      resources.metal += Math.floor(Math.random() * 10) + 1;
    }
    updateResources();
  });

  // Makes the woods picture clickable
  woodBtn.addEventListener("click", () => {
    const resources = getResources();
    resources.wood += Math.floor(Math.random() * 7) + 1; // You get an amount of wood between 1 and 7
    updateResources();
  });
};