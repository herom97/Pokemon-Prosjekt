const armyModules = (function () {
  const armyItems = [
    {categoryName: 'Warrior', name: 'Pikachu', priceGold: 150, image: 'images/warrior1.jpg'},
    {categoryName: 'Warrior', name: 'Charizard', priceGold: 200, image: 'images/warrior2.jpg'},
    {categoryName: 'Warrior', name: 'Blastoise', priceGold: 250, image: 'images/warrior3.jpg'},
    {categoryName: 'Warrior', name: 'Venusaur', priceGold: 300, image: 'images/warrior4.jpg'},
    {categoryName: 'Warrior', name: 'Snorlax', priceGold: 350, image: 'images/warrior5.jpg'},
    {categoryName: 'Warrior', name: 'Gengar', priceGold: 400, image: 'images/warrior6.jpg'},
    {categoryName: 'Combat Force', name: 'Fire Energy(Inferno Core)', priceGold: 200, priceMetal: 100, image: 'images/source1.jpg'},
    {categoryName: 'Combat Force', name: 'Water Energy(Aque Core)', priceGold: 200, priceMetal: 100, image: 'images/source2.jpg'},
    {categoryName: 'Combat Force', name: 'Grass Energy(Verdant Core)', priceGold: 200, priceMetal: 100, image: 'images/source3.jpg'},
    {categoryName: 'Combat Force', name: 'Zapdos', priceGold: 300, priceWood: 100, image: 'images/source4.jpg'},
    {categoryName: 'Combat Force', name: 'Gyrados', priceGold: 300, priceWood: 100, image: 'images/source5.jpg'},
    {categoryName: 'Combat Force', name: 'Arcanine', priceGold: 300, priceWood: 100, image: 'images/source6.jpg'}
  ];

  // Funksjon for å vise elementer basert på kategori
  function showItems(containerId, categoryName) {
    const container = document.getElementById(containerId);
    let itemsHTML = ''; 

    armyItems.filter(item => item.categoryName === categoryName).forEach(item => {
      itemsHTML += `
        <div class="card">
        <img src="${item.image}" alt="${item.name}">
        <h3>${item.name}</h3>
        <p>Price: ${item.priceGold} Gold</p>
        ${item.priceMetal ? `<p>Price: ${item.priceMetal} Metal</p>` : ''}
        ${item.priceWood ? `<p>Price: ${item.priceWood} Wood</p>` : ''}
        <button>
          <img src="images/gold.png" alt="coin" style="width: 2vh;"> Buy ${item.name}
        </button>
        </div>
      `;
    });

    container.innerHTML = itemsHTML; // Setter all HTML i en container
  }

  return {
    showItems, // Brukes for å vise items basert på kategori
    armyItems // Tilgjengelig for kjøpsfunksjonalitet
  };
})();

export default armyModules;





/*const armyModules = (function () {

  // Array av warriors objekter som inneholder nav, pris i gull og bilde
  const warriors = [
    {warriorName: 'Pikachu', priceGold: 150, image: 'images/warrior1.jpg'},
    {warriorName: 'Charizard', priceGold: 200, image: 'images/warrior2.jpg'},
    {warriorName: 'Blastoise', priceGold: 250, image: 'images/warrior3.jpg'},
    {warriorName: 'Venusaur', priceGold: 300, image: 'images/warrior4.jpg'},
    {warriorName: 'Snorlax', priceGold: 350, image: 'images/warrior5.jpg'},
    {warriorName: 'Gengar', priceGold: 400, image: 'images/warrior6.jpg'}
  ];

  // Array av combat forces objekter (våpen) med pris i gull, metall og tre
  const combatWeapons = [
    {weapon: 'Fire Energy(Inferno Core)', priceGold: 200, priceMetal: 100, image: 'images/source1.jpg'},
    {weapon: 'Water Energy(Aque Core)', priceGold: 200, priceMetal: 100, image: 'images/source2.jpg'},
    {weapon: 'Grass Energy(Verdant Core)', priceGold: 200, priceMetal: 100, image: 'images/source3.jpg'},
    {weapon: 'Zapdos', priceGold: 300, priceWood: 100, image: 'images/source4.jpg'},
    {weapon: 'Gyrados', priceGold: 300, priceWood: 100, image: 'images/source5.jpg'},
    {weapon: 'Arcanine', priceGold: 300, priceWood: 100, image: 'images/source6.jpg'}
  ];

  // Funksjon for å vise warriors i en container 
  function showWarriors(containerId) {
    const container = document.getElementById(containerId);
    let warriorsHTML = ''; 

    warriors.forEach(warrior => {
      warriorsHTML += `
        <div class="card">
        <img src="${warrior.image}" alt="${warrior.warriorName}">
        <h3>${warrior.warriorName}</h3>
        <p>Price: ${warrior.priceGold} Gold</p>
        <button>
          <img src="images/gold.png" alt="coin" style="width: 2vh;"> Buy ${warrior.warriorName}
        </button>
        </div>
      `;
    });

    container.innerHTML = warriorsHTML; // Setter all HTML-en i container 
  }
  // Funksjon for å vise combat forces (våpen) i en container
  function showCombatWeapons(containerId) {
    const container = document.getElementById(containerId);
    let combatWeaponsHTML = ''; 

    combatWeapons.forEach(weapon => {
      combatWeaponsHTML += `
        <div class="card">
        <img src="${weapon.image}" alt="${weapon.weapon}">
        <h3>${weapon.weapon}</h3>
        <p>Price: ${weapon.priceGold} Gold</p>
        ${weapon.priceMetal ? `<p>Price: ${weapon.priceMetal} Metal</p>` : ''}
        ${weapon.priceWood ? `<p>Price: ${weapon.priceWood} Wood</p>` : ''}
        <button>
          <img src="images/gold.png" alt="coin" style="width: 2vh;"> Buy ${weapon.weapon}
        </button>
        </div>
      `;
    });

    container.innerHTML = combatWeaponsHTML; 
  }
    
  return {
    showWarriors,
    showCombatWeapons,
    warriors,
    combatWeapons
  }; 
})();

// Eksporterer armyModules
export default armyModules;

*/