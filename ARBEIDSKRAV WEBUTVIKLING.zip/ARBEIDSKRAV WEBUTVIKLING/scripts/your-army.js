import { loadResources, updateResources } from './utilities/resourceUtil.js';  // Importer funksjonene fra resourceUtil.js

// Funksjon for å vise kjøpte enheter fra localStorage
const loadArmyResources = () => {
  const army = JSON.parse(localStorage.getItem('armyResources')) || [];
  const armyContainer = document.getElementById('army');
  const weaponContainer = document.getElementById('combat-weapons');

  // Tømmer containerne før vi legger til elementer. 
  armyContainer.innerHTML = '';
  weaponContainer.innerHTML = '';

  army.forEach(item => {
    const itemElement = document.createElement('div');
    itemElement.classList.add('army-item'); // Legg til en CSS-klasse for styling

    // Bygger HTML for å vise bildet og navn
    itemElement.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <h3>${item.name}</h3>
    `;

    // Sjekker om elementet er en warrior eller combat force
    if (item.categoryName === 'Warrior') {
      armyContainer.appendChild(itemElement); // Legger til i warrior-containeren
    } else if (item.categoryName === 'Combat Force') {
      weaponContainer.appendChild(itemElement); // Legger til i combat force-containeren
    }
  });
};

// Når siden lastes inn, vis ressurser og kjøpte enheter
window.onload = () => {
  loadResources(); // Laster og viser ressurser fra localStorage
  updateResources();   
  loadArmyResources(); // Laster og viser army-resurser fra localStorage
};




/*

// Bygger HTML for å vise bildet og navn
    itemElement.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <h3>${item.name}</h3>
      <p>Price: ${item.priceGold} Gold</p>
      ${item.priceMetal ? `<p>Price: ${item.priceMetal} Metal</p>` : ''}
      ${item.priceWood ? `<p>Price: ${item.priceWood} Wood</p>` : ''}
    `;

*/



